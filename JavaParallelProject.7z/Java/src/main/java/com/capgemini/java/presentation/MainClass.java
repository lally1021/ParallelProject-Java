package com.capgemini.java.presentation;

import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;
import com.capgemini.java.service.BankService;
import com.capgemini.java.service.BankServiceImpl;

public class MainClass {

	public static void main(String[] args) throws BankException {
		
		String continueChoice;
		boolean continueValue = false;
		Set<Transaction> st11=new LinkedHashSet<>();

		Scanner scanner = null;
		do {
			
			System.out.println("*** welcome to Banking***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			System.out.println("6.Print Transactions");
			System.out.println("7.exit");
			
			BankService service = new BankServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;
			
			do {
				
				
				System.out.println("Enter input:");
				
				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean flag = false;
					boolean checkAccount=false;
					 //String recieverAccountNo="";
					 long balance=0;
					 double bal=0;
					 long amountDeposited=0;
					 long transferAmount=0;
					 long accountNo=0;
					 long accNo=0;
					 long amountWithdrawl=0;
					 //long balanceAfterDeposition=0;
                   
					switch (choice) {
					case 1:
					{
						 String senderName="";
						 
						/*String middleName="";
						String lastName="";*/
						do {
						scanner = new Scanner(System.in);
						System.out.println("Enter sender Name:");
						senderName=scanner.next();
						try {
							service.validateName(senderName);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						/*do {
							scanner = new Scanner(System.in);
						System.out.println("Enter Middle Name:");
						middleName=scanner.next();
						try {
							service.validateName(middleName);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter Last Name:");
						lastName=scanner.next();
						try {
							service.validateName(lastName);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						String name="";
						
						do {
							scanner = new Scanner(System.in);
						name=firstName.concat(middleName.concat(lastName));
						try {
							service.validateName(name);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);*/
						
						
						
						String senderMobile="";
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter mobile number:");
						senderMobile=scanner.next();
						try {
							service.validateNumber(senderMobile);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						
						String gender="";
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter Gender:");
						 gender=scanner.next();
						if(gender.equals("male")) {
							gender="Male";
							flag=true;
						}
						else if(gender.equals("female")) {
							gender="Female";
							flag=true;
						}
						else {
							System.out.println("gender should be in characters and it should be either male or female");
							flag=false;
						}
						}while (!flag);
						
						
						 balance=0;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							balance=scanner.nextLong();
							try {
								service.validateAmount(balance);
								flag = true;
							} catch (BankException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
							}while (!flag);
						accountNo = service.senderGenerateId();
						System.out.println("senderAccountNo created with the id: " + accountNo);
						Account account = new Account(accountNo,balance,senderName,gender,senderMobile);
						service.addAccount(accountNo,account);
						
						
						}
						break;
					
					case 2:
						
					{
						System.out.println("Enter account number:");
						scanner = new Scanner(System.in);
							accountNo=scanner.nextLong();
							Account account=service.checkAccountNo(accountNo);
                        System.out.println("Enter amount to be deposited:");
                    scanner = new Scanner(System.in);
                     amountDeposited = scanner.nextLong();
                    LocalDate date = LocalDate.now();
							
                     long balanceAfterDeposit=service.deposit(accountNo, amountDeposited);
                     System.out.println( "final balance="+balanceAfterDeposit);
                     int transacId = service.transacId();
                     SimpleDateFormat formatter=new SimpleDateFormat("dd-mm-yyyy HH:mm:ss");
						Date dt=new Date();
						String date1=formatter.format(dt);
                     Transaction transaction = new Transaction(transacId, "deposit", "date1", accountNo,balanceAfterDeposit);
                     
                     service.addTransaction(transaction);
                     
                    
                        }
                        break;
					
					case 3:{
						System.out.println("Enter account number to withdrawl:");
						
						scanner = new Scanner(System.in);
							accountNo=scanner.nextLong();
							Account account=service.checkAccountNo(accountNo);
						System.out.println("Enter amount to be withdraw:");
	                    scanner = new Scanner(System.in);
	                     amountWithdrawl = scanner.nextLong();
	                    LocalDate date = LocalDate.now();
	                     long balanceAfterWithdrawl=service.withdrawl(accountNo, amountWithdrawl);
	                     System.out.println( "remaining balance="+balanceAfterWithdrawl);
	                     int transacId = service.transacId();
	                     SimpleDateFormat formatter=new SimpleDateFormat("dd-mm-yyyy HH:mm:ss");
							Date dt=new Date();
							String d=formatter.format(dt);
	                     Transaction transaction = new Transaction(transacId, "withdrawl", "d", accountNo,balanceAfterWithdrawl);
	                     service.addTransaction(transaction);
					}
						break;
						
					case 4:{
						String receiverName="";
						
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Receivername:");
							receiverName = scanner.next();
							try {
								service.validateName(receiverName);
								flag = true;
							} catch (BankException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
							}while (!flag);
						
						String receiverMobile="";
						do {
							scanner = new Scanner(System.in);
						System.out.println("Enter mobile number:");
						receiverMobile=scanner.next();
						try {
							service.validateNumber(receiverMobile);
							flag = true;
						} catch (BankException e) {
							flag = false;
							System.err.println(e.getMessage());
						}
						}while (!flag);
						
						
						long receiveraccountNo = service.receiverGenerateId();
						System.out.println("receiverAccountNo created with the id: " + receiveraccountNo);
						Account account1 = new Account(receiveraccountNo,balance,receiverName,null,receiverMobile);
						service.addAccount(accountNo,account1);
						
						System.out.println("Enter sender's account number:");
						scanner = new Scanner(System.in);
						accountNo = scanner.nextLong();
						
						System.out.println("Enter receiver's account number:");
						scanner = new Scanner(System.in);
						long receiverAccountNo = scanner.nextLong();
						System.out.println("Enter Receiver Account holder name:");
						String receiverName1 = scanner.next();
  							
                          try {
                        Account account=service.checkAccountNo(accountNo);
                        
                        System.out.println("Enter amount to be transferred:");
						long amount=scanner.nextLong();
						service.validateAmount(amount);  
						
						balance = account.getBalance();			
						//System.out.println(balance);
						balance= balance-amount;
						account.setBalance(balance);
						System.out.println("amount transferred successfully");
					
						long balanceAfterTransaction=account1.getBalance();
						balanceAfterTransaction= balanceAfterTransaction+amount;
						account1.setBalance(balanceAfterTransaction);
						
						System.out.println("after fund transfer your balance is:"+balance);
						 checkAccount = true;
						SimpleDateFormat formatter=new SimpleDateFormat("dd-mm-yyyy HH:mm:ss");
						Date dt=new Date();
						String date2=formatter.format(dt);
						int transacId = service.transacId();
						Transaction transaction = new Transaction(transacId,"fundtransfer","date1",accountNo ,balance);
                        service.addTransaction(transaction);
                          }catch (BankException e) {
							System.out.println(e.getMessage());
						}
                          /*System.out.println("Enter amount to be transferred:");
							scanner = new Scanner(System.in);
							transferAmount=scanner.nextInt();
							
							try {
								service.validateAmount(transferAmount);
								flag = true;
							} catch (BankException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
							
						}while(!flag);
                    long balanceAfterTransaction=service.addTransaction(senderAccountNo,recieverAccountNo,transferAmount);
                    System.out.println( "remaining balance="+balanceAfterTransaction);
                    int transacId = service.transacId();
                    LocalDate date1 = LocalDate.now();
                    Transaction transaction = new Transaction(transacId, "deposit", date1, accountNo,balanceAfterTransaction);
                    service.addTransaction(transaction);*/  
                        	  
					}
						break;
						
					case 5:
					{
								System.out.println("Enter your account number:");
								scanner = new Scanner(System.in);
									accountNo=scanner.nextLong();
									Account account=service.checkAccountNo(accountNo);
									bal=service.getBalance(accountNo);
									  System.out.println("Your account balance is:"+bal);
					}
						break;
						
					case 6:
						 {
							 System.out.println("Enter your account number:");
								
								scanner = new Scanner(System.in);
									accountNo=scanner.nextLong();
									Account account=service.checkAccountNo(accountNo);
                                    System.out.println("your transactions are as mentioned:");
                                    scanner = new Scanner(System.in);
                                  System.out.println(service.printTransaction());
                                  
                                }
						break;
						
					case 7:
					
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
						
					default:
						
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;
						
					}
				}catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
				
			}while(!choiceFlag);
			
			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
			
		}while (continueValue);
		scanner.close();
	}

}
