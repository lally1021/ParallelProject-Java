package com.capgemini.java.service;

import java.util.Set;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankService {

	public boolean validateName(String name) throws BankException;
	public boolean validateNumber(String mobileNo) throws BankException;
	public boolean validateAmount(double accountNo) throws BankException;
	public Account checkAccountNo(long accountNo) throws BankException;

	public void addAccount(long accountNo, Account account) throws BankException;
	public long deposit(long accNo, long amountDeposited) throws BankException;
	public long withdrawl(long accountNo, long amountWithdrawl) throws BankException;
	//public long addTransaction(long senderAccountNo, long recieverAccountNo, long transferAmount) throws BankException;
	public long getBalance(long accountNo);
	public int transacId();
	public boolean addTransaction(Transaction transaction) throws BankException;
	public Set<Transaction> printTransaction() throws BankException;
	long senderGenerateId() throws BankException;
	long receiverGenerateId() throws BankException;

}
