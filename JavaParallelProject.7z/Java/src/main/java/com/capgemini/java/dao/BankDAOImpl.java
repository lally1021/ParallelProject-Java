package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public class BankDAOImpl implements BankDAO {

	static Map<Long, Account> map = new HashMap<>();
	static Set<Transaction> set = new LinkedHashSet<>();

	@Override
	public long deposit(long accountNumber, long depositedAmount) {
		Iterator<Account> it1 = map.values().iterator();
		Long balance = 4567L;
		while (it1.hasNext()) {
			Account acc = it1.next();
			long acNo = acc.getAccountNo();
			balance = acc.getBalance();
			if (acNo == accountNumber) {
				balance = depositedAmount + balance;
				acc.setBalance(balance);
			}
		}
		return balance;
	}

	@Override
	public long getBalance(long accountNo) {
		// TODO Auto-generated method stub
		Iterator<Account> it1 = map.values().iterator();
		Long balance = 4567L;
		Long finalBalance = 0L;
		while (it1.hasNext()) {
			Account acc = it1.next();
			long acNo = acc.getAccountNo();
			balance = acc.getBalance();
			if (acNo == accountNo) {
				finalBalance = balance;
			}
		}
		return finalBalance;
	}

	@Override
	public void addAccount(long accountNo, Account account) {
		map.put(accountNo, account);
	}

	@Override
	public long withdrawl(long accountNo, long amountWithdrawl) {
		Iterator<Account> it2 = map.values().iterator();
		Long balance = 4567L;
		while (it2.hasNext()) {
			Account acc = it2.next();
			long acNo = acc.getAccountNo();
			balance = acc.getBalance();
			if (acNo == accountNo) {
				balance = balance - amountWithdrawl;
				acc.setBalance(balance);
			}
		}
		return balance;
	}

	/*@Override
	public long transaction(long senderAccountNo, long recieverAccountNo, long transferAmount) {
		Iterator<Account> it1 = map.values().iterator();
		Long balance1 = 4567L;
		Long balance2 = 4567L;
		while (it1.hasNext()) {
			Account acc1 = it1.next();
			long acNo1 = acc1.getAccountNo();
			balance1 = acc1.getBalance();
			if (acNo1 == senderAccountNo) {
				while (it1.hasNext()) {
					Account acc2 = it1.next();
					long acNo2 = acc2.getAccountNo();
					balance2 = acc2.getBalance();
					if (acNo2 == recieverAccountNo) {
						balance2 = transferAmount + balance2;
						balance1 = balance1 - transferAmount;
						acc2.setBalance(balance2);
						acc1.setBalance(balance1);
					}
				}
			}
		}
		return balance1;
	}*/

	@Override
	public boolean addTraansaction(Transaction transaction) throws BankException {
		set.add(transaction);
		return true;
	}

	@Override
	public Set<Transaction> printTransaction() throws BankException {
		return set;
	}

	@Override
	public Account checkaccountNo(long accountNo) throws BankException {
		boolean status=false;
		Account account = null;
		Iterator<Account> iterator=map.values().iterator();
		while(iterator.hasNext()) {
		 account=iterator.next();
			if(account.getAccountNo()==accountNo) {
				status=true;
			}
			if(status==true) {
				break;
			}
		}
		if(status==false)
			throw new BankException("accountNo not found");
	
		return account;
	
	}

}
